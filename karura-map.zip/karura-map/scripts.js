// Import configuration. Using dynamic import because modules are supported in browsers with type="module".
// Configuration for the map and donation details. This replicates the data in src/data/mapConfig.js.
const mapConfig = {
  appName: 'Karura Forest Trail Companion',
  sponsorName: "Kenya Children’s Home",
  tagline:
    'A free digital trail companion for Karura Forest visitors, developed as a public resource by Kenya Children’s Home.',
  center: {
    lat: -1.236,
    lng: 36.821,
  },
  defaultZoom: 14,
  showPrototypeBanner: true,
  donation: {
    paybill: '[Insert PayBill Number]',
    accountReference: 'Karura Map',
    websiteUrl: '[Insert Kenya Children’s Home Website]',
  },
};

// Helper function to fetch GeoJSON data from local files.
async function loadGeoJson(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to load ${url}: ${response.status}`);
  }
  return response.json();
}

// Initialize the map once the document is ready.
document.addEventListener('DOMContentLoaded', async () => {
  // Create the map instance
  const map = new maplibregl.Map({
    container: 'map',
    style: 'https://demotiles.maplibre.org/style.json',
    center: [mapConfig.center.lng, mapConfig.center.lat],
    zoom: mapConfig.defaultZoom,
    attributionControl: true,
  });

  // Add zoom and rotation controls
  map.addControl(new maplibregl.NavigationControl(), 'bottom-right');

  // Load GeoJSON files in parallel
  const [trailsData, poiData, junctionData] = await Promise.all([
    loadGeoJson('./src/data/trails.geojson'),
    loadGeoJson('./src/data/points-of-interest.geojson'),
    loadGeoJson('./src/data/junctions.geojson'),
  ]);

  // Add sources and layers once map has loaded
  map.on('load', () => {
    // Trails source and layer
    map.addSource('trails', {
      type: 'geojson',
      data: trailsData,
    });
    map.addLayer({
      id: 'trails-line',
      type: 'line',
      source: 'trails',
      paint: {
        'line-color': ['get', 'colour'],
        'line-width': 4,
        'line-opacity': 0.8,
      },
    });

    // Points of interest source and layer
    map.addSource('pois', {
      type: 'geojson',
      data: poiData,
    });
    map.addLayer({
      id: 'pois-circle',
      type: 'circle',
      source: 'pois',
      paint: {
        'circle-radius': 6,
        'circle-color': '#007cbf',
        'circle-stroke-width': 1,
        'circle-stroke-color': '#fff',
      },
    });

    // Junctions source and layer (optional display as small circles)
    map.addSource('junctions', {
      type: 'geojson',
      data: junctionData,
    });
    map.addLayer({
      id: 'junctions-circle',
      type: 'circle',
      source: 'junctions',
      paint: {
        'circle-radius': 4,
        'circle-color': '#FF69B4',
        'circle-stroke-width': 1,
        'circle-stroke-color': '#fff',
      },
    });
  });

  // Info panel element
  const infoPanel = document.getElementById('infoPanel');

  // Click interaction for trails
  map.on('click', 'trails-line', (e) => {
    // Get properties of clicked feature
    const features = map.queryRenderedFeatures(e.point, {
      layers: ['trails-line'],
    });
    if (!features.length) return;
    const properties = features[0].properties;
    // Populate info panel with details
    infoPanel.innerHTML = '';
    const title = document.createElement('h3');
    title.className = 'text-lg font-semibold mb-2';
    title.textContent = properties.name;
    infoPanel.appendChild(title);
    // Build a list of key details
    const details = [
      { label: 'Distance', value: properties.distance_km ? `${properties.distance_km} km` : 'To be verified' },
      { label: 'Estimated time', value: properties.estimated_time || 'To be verified' },
      { label: 'Difficulty', value: properties.difficulty || 'To be verified' },
      { label: 'Type', value: properties.type || 'To be verified' },
      { label: 'Surface', value: properties.surface || 'To be verified' },
      { label: 'Starts from', value: properties.starts_from || 'To be verified' },
    ];
    const list = document.createElement('ul');
    list.className = 'text-sm space-y-1';
    details.forEach((item) => {
      const li = document.createElement('li');
      li.innerHTML = `<strong>${item.label}:</strong> ${item.value}`;
      list.appendChild(li);
    });
    infoPanel.appendChild(list);
    // Description and status
    const description = document.createElement('p');
    description.className = 'mt-2 text-sm';
    description.textContent = properties.description || '';
    infoPanel.appendChild(description);
    if (properties.status) {
      const note = document.createElement('p');
      note.className = 'mt-2 text-xs text-yellow-700 italic';
      note.textContent = properties.status;
      infoPanel.appendChild(note);
    }
    // Show panel
    infoPanel.classList.remove('hidden');
  });

  // Hide info panel when map is clicked elsewhere
  map.on('click', (e) => {
    const features = map.queryRenderedFeatures(e.point, {
      layers: ['trails-line'],
    });
    if (!features.length) {
      infoPanel.classList.add('hidden');
    }
  });

  // Popups for points of interest
  map.on('click', 'pois-circle', (e) => {
    const feature = e.features[0];
    const coords = feature.geometry.coordinates.slice();
    const props = feature.properties;
    const html = `<strong>${props.name}</strong><br />
    Category: ${props.category}<br />
    ${props.description}<br />
    <em>${props.visitor_note}</em><br />
    <small>${props.status}</small>`;
    new maplibregl.Popup()
      .setLngLat(coords)
      .setHTML(html)
      .addTo(map);
  });

  // Cursor pointer on hover for interactive layers
  ['trails-line', 'pois-circle'].forEach((layer) => {
    map.on('mouseenter', layer, () => {
      map.getCanvas().style.cursor = 'pointer';
    });
    map.on('mouseleave', layer, () => {
      map.getCanvas().style.cursor = '';
    });
  });

  // Geolocation button handler
  const locateBtn = document.getElementById('locateBtn');
  locateBtn.addEventListener('click', () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }
    locateBtn.disabled = true;
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        // Move map to user location
        map.flyTo({ center: [longitude, latitude], zoom: 16 });
        // Add a marker at user location
        new maplibregl.Marker({ color: '#E12D39' })
          .setLngLat([longitude, latitude])
          .addTo(map);
        locateBtn.disabled = false;
      },
      (error) => {
        alert('Unable to retrieve your location.');
        console.error(error);
        locateBtn.disabled = false;
      },
      { enableHighAccuracy: true }
    );
  });

  // Filter controls
  const categories = [
    'All',
    'Walking',
    'Running',
    'Cycling',
    'Family',
    'Landmarks',
    'Facilities',
    'Safety',
    'Gates',
  ];
  const filterContainer = document.getElementById('filterContainer');

  categories.forEach((cat) => {
    const button = document.createElement('button');
    button.textContent = cat;
    button.className =
      'px-2 py-1 rounded bg-gray-200 hover:bg-gray-300 text-gray-800 focus:outline-none';
    button.addEventListener('click', () => applyFilter(cat));
    filterContainer.appendChild(button);
  });

  // Apply filters to show/hide layers based on category
  function applyFilter(category) {
    // Reset filters
    map.setFilter('trails-line', null);
    map.setFilter('pois-circle', null);
    if (category === 'All') {
      return;
    }
    // Filtering logic for trails: currently not implemented; trails remain visible regardless of category
    // Filtering logic for points of interest based on category mapping
    const categoryMap = {
      Landmarks: 'Landmark',
      Facilities: 'Facilities',
      Gates: 'Gate',
      Safety: 'Safety',
    };
    if (categoryMap[category]) {
      map.setFilter('pois-circle', ['==', ['get', 'category'], categoryMap[category]]);
    }
  }

  // Modal handling
  function showModal(modal) {
    // Show modal by removing hidden class and applying flex display
    modal.classList.remove('hidden');
    if (!modal.classList.contains('flex')) {
      modal.classList.add('flex');
    }
    modal.setAttribute('aria-hidden', 'false');
  }
  function hideModal(modal) {
    // Hide modal by adding hidden class and removing flex display
    modal.classList.add('hidden');
    modal.classList.remove('flex');
    modal.setAttribute('aria-hidden', 'true');
  }
  const aboutModal = document.getElementById('aboutModal');
  const donateModal = document.getElementById('donateModal');
  const safetyModal = document.getElementById('safetyModal');
  // Buttons to open modals
  document.getElementById('aboutBtn').addEventListener('click', () => showModal(aboutModal));
  document.getElementById('donateBtn').addEventListener('click', () => showModal(donateModal));
  document.getElementById('safetyBtn').addEventListener('click', () => showModal(safetyModal));
  // Close modal buttons
  document.querySelectorAll('.closeModal').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const modal = e.target.closest('.modal');
      hideModal(modal);
    });
  });
  // Clicking outside modal content closes modal
  [aboutModal, donateModal, safetyModal].forEach((modal) => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        hideModal(modal);
      }
    });
  });
  // Support button inside About modal triggers donation modal
  document.getElementById('aboutSupportBtn').addEventListener('click', () => {
    hideModal(aboutModal);
    showModal(donateModal);
  });
  // Visit website button placeholder; open new window with configured URL
  document.getElementById('visitWebsiteBtn').addEventListener('click', () => {
    const url = mapConfig.donation.websiteUrl;
    if (url && url.startsWith('http')) {
      window.open(url, '_blank');
    }
  });
});