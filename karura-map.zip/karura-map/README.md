# Karura Forest Digital Trail Companion

## Purpose

A free digital trail companion for Karura Forest visitors, developed as a public resource by Kenya Children’s Home. The map helps visitors explore Karura more confidently by showing trails, gates, landmarks, facilities and points of interest on an easy‑to‑use, mobile‑first map.

## Current Status

Prototype / MVP. Trail and point data must be verified before public launch. Sample routes, points of interest and junctions are provided in the `/src/data` directory. These coordinates and descriptive details are placeholders and must be replaced with verified data collected in the field.

## Running Locally

This repository is a lightweight static build that does not require a build step. To run it locally you can simply open `index.html` in a web browser or serve the directory with a simple HTTP server. For example:

```bash
python3 -m http.server --directory karura-map
```

Then navigate to `http://localhost:8000` in your browser. You should see the map centred on Karura Forest with sample routes and points of interest. Clicking a trail will display an information panel. Clicking a point of interest opens a popup. The **About**, **Donate** and **Safety** buttons open modals with the respective text.

## Updating Map Data

All map data lives in the `/src/data` directory:

* `trails.geojson` – sample trail line features.
* `points-of-interest.geojson` – sample point of interest features.
* `junctions.geojson` – sample junction point features.
* `mapConfig.js` – configuration used by the scripts (for information only; actual configuration is duplicated in `scripts.js`).

Edit these files to add or replace features. Each feature should include a `status` property set to `"Sample data - verify before public launch"` unless verified. You can generate GeoJSON with any GIS tool or by exporting GPS tracks. Take care to follow Karura Forest’s official signage and route numbering when naming trails and junctions.

## Updating Donation Details

Donation details appear in the **Donate** modal. Update the `donation` section of `src/data/mapConfig.js` and replicate those changes in the `mapConfig` constant defined at the top of `scripts.js`. This duplication ensures the static build can load without requiring an ES module import. Replace the placeholders for PayBill and web address with the actual Kenya Children’s Home donation information.

## Data Verification

All trail, gate, junction, facility and point‑of‑interest data must be verified against official signage, approved sources or GPS field checks before public launch. The MVP intentionally labels sample data clearly so users understand the information may not be accurate. Do not remove the verification note until data has been validated.

## Deployment

The application is designed to run as a static site, which makes it easy to deploy. You can host the contents of the `karura-map` directory on any web server or static hosting platform such as Vercel, Netlify or GitHub Pages. When deploying to a static host, ensure that all files in `src/data` and the script are included and served relative to the root.

For a more robust production build using React/Next.js, you may generate a full application based on this structure and integrate MapLibre or Leaflet with proper bundling. However, this prototype demonstrates the core functionality without requiring node modules or a build toolchain.